import 'package:get/get.dart';

class AuthController extends GetxController {}
