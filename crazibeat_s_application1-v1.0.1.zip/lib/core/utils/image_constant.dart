class ImageConstant {
  static String imgTelevision = 'assets/images/img_television.svg';

  static String imgArrowdown43x82 = 'assets/images/img_arrowdown_43x82.svg';

  static String imgCar = 'assets/images/img_car.svg';

  static String imgQrcode = 'assets/images/img_qrcode.svg';

  static String imgGroupWhiteA700 = 'assets/images/img_group_white_a700.svg';

  static String imgGroup3500 = 'assets/images/img_group3500.svg';

  static String imgGroup3494 = 'assets/images/img_group3494.svg';

  static String imgGrid = 'assets/images/img_grid.svg';

  static String imgOffer = 'assets/images/img_offer.png';

  static String imgVector = 'assets/images/img_vector.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgClock6x96 = 'assets/images/img_clock_6x96.svg';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  static String imgFrame555 = 'assets/images/img_frame555.svg';

  static String imgGroup210 = 'assets/images/img_group210.svg';

  static String imgVector10x8 = 'assets/images/img_vector_10x8.svg';

  static String imgClose = 'assets/images/img_close.svg';

  static String imgArrowup = 'assets/images/img_arrowup.svg';

  static String imgMusic = 'assets/images/img_music.svg';

  static String imgFrame803 = 'assets/images/img_frame803.svg';

  static String imgLock = 'assets/images/img_lock.svg';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgEllipse5 = 'assets/images/img_ellipse5.png';

  static String imgVolume16x16 = 'assets/images/img_volume_16x16.svg';

  static String imgGroupDeepPurpleA20002 =
      'assets/images/img_group_deep_purple_a200_02.svg';

  static String imgEllipse81 = 'assets/images/img_ellipse81.png';

  static String imgClock = 'assets/images/img_clock.svg';

  static String imgBlueishlights = 'assets/images/img_blueishlights.png';

  static String imgVideocamera = 'assets/images/img_videocamera.svg';

  static String imgWallpaper = 'assets/images/img_wallpaper.png';

  static String imgAirplane = 'assets/images/img_airplane.svg';

  static String imgFingerprint = 'assets/images/img_fingerprint.svg';

  static String imgCalculator = 'assets/images/img_calculator.svg';

  static String imgFrame3497 = 'assets/images/img_frame_3497.svg';

  static String imgReply = 'assets/images/img_reply.svg';

  static String imgGroup3 = 'assets/images/img_group3.svg';

  static String imgGroup9 = 'assets/images/img_group9.svg';

  static String imgGroup3493 = 'assets/images/img_group3493.svg';

  static String imgArrowright20x10 = 'assets/images/img_arrowright_20x10.svg';

  static String imgClose32x32 = 'assets/images/img_close_32x32.svg';

  static String imgVolume12x12 = 'assets/images/img_volume_12x12.svg';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgGroup8 = 'assets/images/img_group8.svg';

  static String imgFrame774 = 'assets/images/img_frame774.svg';

  static String imgIconBlue700 = 'assets/images/img_icon_blue_700.svg';

  static String imgVolume43x82 = 'assets/images/img_volume_43x82.svg';

  static String imgEllipse4965x65 = 'assets/images/img_ellipse49_65x65.png';

  static String imgGroup6 = 'assets/images/img_group6.svg';

  static String imgGroup195 = 'assets/images/img_group195.svg';

  static String imgGroup3496Blue200 =
      'assets/images/img_group3496_blue_200.png';

  static String imgGroup209 = 'assets/images/img_group209.png';

  static String imgGroup205 = 'assets/images/img_group205.svg';

  static String imgGroup = 'assets/images/img_group.svg';

  static String imgGroupDeepPurple800 =
      'assets/images/img_group_deep_purple_800.svg';

  static String imgSettings = 'assets/images/img_settings.svg';

  static String imgGroup363 = 'assets/images/img_group363.svg';

  static String imgCrop = 'assets/images/img_crop.svg';

  static String imgWallpaper175x319 = 'assets/images/img_wallpaper_175x319.png';

  static String imgArrowdown6x96 = 'assets/images/img_arrowdown_6x96.svg';

  static String imgIcon = 'assets/images/img_icon.svg';

  static String imgSettings12x12 = 'assets/images/img_settings_12x12.svg';

  static String imgGroup3493BlueA200 =
      'assets/images/img_group3493_blue_a200.svg';

  static String imgUpload = 'assets/images/img_upload.svg';

  static String imgTrophy70x61 = 'assets/images/img_trophy_70x61.svg';

  static String imgEllipse49 = 'assets/images/img_ellipse49.png';

  static String imgBluetooth = 'assets/images/img_bluetooth.svg';

  static String imgSettings94x69 = 'assets/images/img_settings_94x69.svg';

  static String imgNotification = 'assets/images/img_notification.svg';

  static String imgMenu48x48 = 'assets/images/img_menu_48x48.svg';

  static String imgArrowright10x8 = 'assets/images/img_arrowright_10x8.svg';

  static String imgGroup188 = 'assets/images/img_group188.png';

  static String imgT = 'assets/images/img_t.svg';

  static String imgGroupBlue700 = 'assets/images/img_group_blue_700.svg';

  static String imgArrowright6x14 = 'assets/images/img_arrowright_6x14.svg';

  static String imgPlus = 'assets/images/img_plus.svg';

  static String imgVolume = 'assets/images/img_volume.svg';

  static String imgMail = 'assets/images/img_mail.svg';

  static String imgLogoonblacktshirt =
      'assets/images/img_logoonblacktshirt.png';

  static String imgVector28 = 'assets/images/img_vector28.png';

  static String imgGrid7x21 = 'assets/images/img_grid_7x21.svg';

  static String imgOnboardingfour = 'assets/images/img_onboardingfour.png';

  static String imgGroup196 = 'assets/images/img_group196.png';

  static String imgCamera = 'assets/images/img_camera.svg';

  static String imgGroup197 = 'assets/images/img_group197.svg';

  static String imgStar = 'assets/images/img_star.svg';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgOnboardingtwo = 'assets/images/img_onboardingtwo.png';

  static String imgTicket = 'assets/images/img_ticket.svg';

  static String imgVector9x12 = 'assets/images/img_vector_9x12.svg';

  static String imgArrowrightBlack900 =
      'assets/images/img_arrowright_black_900.svg';

  static String imgPolygon2 = 'assets/images/img_polygon2.svg';

  static String imgEye = 'assets/images/img_eye.svg';

  static String imgTrophy = 'assets/images/img_trophy.svg';

  static String imgQuestion = 'assets/images/img_question.svg';

  static String imgVectorGray5001 = 'assets/images/img_vector_gray_50_01.svg';

  static String imgArrowrightGray600 =
      'assets/images/img_arrowright_gray_600.svg';

  static String imgCalendar = 'assets/images/img_calendar.svg';

  static String imgUpload72x72 = 'assets/images/img_upload_72x72.svg';

  static String imgFrame801 = 'assets/images/img_frame801.svg';

  static String imgRectangle255 = 'assets/images/img_rectangle255.png';

  static String imgWarning26a0fe0f = 'assets/images/img_warning26a0fe0f.png';

  static String imgGroup3494BlueA200 =
      'assets/images/img_group3494_blue_a200.svg';

  static String imgGroup189 = 'assets/images/img_group189.png';

  static String imgMaximize = 'assets/images/img_maximize.svg';

  static String imgGroup7 = 'assets/images/img_group7.svg';

  static String imgHome = 'assets/images/img_home.svg';

  static String imgVector33 = 'assets/images/img_vector33.png';

  static String img = 'assets/images/img_.svg';

  static String imgGroupGreen40001 = 'assets/images/img_group_green_400_01.svg';

  static String imgVector35 = 'assets/images/img_vector35.png';

  static String imgGroup190 = 'assets/images/img_group190.svg';

  static String imgQuestion34x29 = 'assets/images/img_question_34x29.svg';

  static String imgGroup3496 = 'assets/images/img_group3496.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
